/*
  base2 - copyright 2007-2009, Dean Edwards
  http://code.google.com/p/base2/
  http://www.opensource.org/licenses/mit-license.php

  Contributors:
    Doeke Zanstra
*/
var base2={name:"base2",version:"1.0.1 (alpha1)",exports:"Base,Package,Abstract,Module,Enumerable,Map,Collection,RegGrp,Undefined,Null,This,True,False,assignID,detect,global",namespace:""};new function(_y){var Undefined=K(),Null=K(null),True=K(true),False=K(false),This=function(){return this};var global=This(),base2=global.base2;var _b=K(),_z=/%([1-9])/g,_i=/^\s\s*/,_j=/\s\s*$/,_k=/([\/()[\]{}|*+-.,^$?\\])/g,_c=/try/.test(detect)?/\bbase\b/:/.*/,_d=["constructor","toString"],_l=detect("(jscript)")?new RegExp("^"+rescape(isNaN).replace(/isNaN/,"\\w+")+"$"):{test:False},_m=1,_2=Array.prototype.slice;_5();function assignID(a,b){if(!b)b="base2ID";if(!a[b])a[b]="b2_"+_m++;return a[b]};var _e=function(a,b){base2.__prototyping=this.prototype;var c=new this;if(a)extend(c,a);delete base2.__prototyping;var d=c.constructor;function e(){if(!base2.__prototyping){if(this.constructor==arguments.callee||this.__constructing){this.__constructing=true;d.apply(this,arguments);delete this.__constructing}else{return extend(arguments[0],c)}}return this};c.constructor=e;for(var f in Base)e[f]=this[f];if(b)extend(e,b);e.ancestor=this;e.ancestorOf=Base.ancestorOf;e.base=Undefined;e.prototype=c;if(e.init)e.init();return e};var Base=_e.call(Object,{constructor:function(){if(arguments.length>0){this.extend(arguments[0])}},base:function(){},extend:delegate(extend),toString:function(){if(this.constructor.toString==Function.prototype.toString){return"[object base2.Base]"}else{return"[object "+this.constructor.toString().slice(1,-1)+"]"}}},Base={ancestorOf:function(a){return _9(this,a)},extend:_e,forEach:function(a,b,c){_5(this,a,b,c)},implement:function(a){if(typeof a=="function"){a=a.prototype}extend(this.prototype,a);return this}});var Package=Base.extend({constructor:function(d,e){var f=this;f.extend(e);if(f.name&&f.name!="base2"){if(e.parent===undefined)f.parent=base2;if(f.parent)f.parent.addName(f.name,f);f.namespace=format("var %1=%2;",f.name,String2.slice(f,1,-1))}if(d){var g=base2.JavaScript?base2.JavaScript.namespace:"";var h="var base2=(function(){return this.base2})();"+base2.namespace+g;var j=csv(f.imports),i;for(var k=0;i=j[k];k++){var l=n(i)||n("JavaScript."+i);if(!l)throw new ReferenceError(format("Object not found: '%1'.",i));h+=l.namespace}d.init=function(){if(f.init)f.init()};d.imports=h+lang.namespace+"this.init();";h="";var o=csv(f.exports);for(var k=0;i=o[k];k++){var m=f.name+"."+i;f.namespace+="var "+i+"="+m+";";h+="if(!"+m+")"+m+"="+i+";"}d.exports=h+"this._n"+f.name+"();";var p=String2.slice(f,1,-1);d["_n"+f.name]=function(){for(var a in f){var b=f[a];if(b&&b.ancestorOf==Base.ancestorOf){b.toString=K("["+p+"."+a+"]")}}}}function n(a){a=a.split(".");var b=base2,c=0;while(b&&a[c]!=null){b=b[a[c++]]}return b}},exports:"",imports:"",name:"",namespace:"",parent:null,addName:function(a,b){if(!this[a]){this[a]=b;this.exports+=","+a;this.namespace+=format("var %1=%2.%1;",a,this.name)}},addPackage:function(a){this.addName(a,new Package(null,{name:a,parent:this}))},toString:function(){return format("[%1]",this.parent?String2.slice(this.parent,1,-1)+"."+this.name:this.name)}});var Abstract=Base.extend({constructor:function(){throw new TypeError("Abstract class cannot be instantiated.");}});var _o=0;var Module=Abstract.extend(null,{namespace:"",extend:function(a,b){var c=this.base();var d=_o++;c.namespace="";c.partial=this.partial;c.toString=K("[base2.Module["+d+"]]");Module[d]=c;c.implement(this);if(a)c.implement(a);if(b){extend(c,b);if(c.init)c.init()}return c},forEach:function(c,d){_5(Module,this.prototype,function(a,b){if(typeOf(a)=="function"){c.call(d,this[b],b,this)}},this)},implement:function(a){var b=this;var c=b.toString().slice(1,-1);if(typeof a=="function"){if(!_9(a,b)){this.base(a)}if(_9(Module,a)){for(var d in a){if(b[d]===undefined){var e=a[d];if(typeof e=="function"&&e.call&&a.prototype[d]){e=_p(a,d)}b[d]=e}}b.namespace+=a.namespace.replace(/base2\.Module\[\d+\]/g,c)}}else{extend(b,a);_f(b,a)}return b},partial:function(){var c=Module.extend();var d=c.toString().slice(1,-1);c.namespace=this.namespace.replace(/(\w+)=b[^\)]+\)/g,"$1="+d+".$1");this.forEach(function(a,b){c[b]=partial(bind(a,c))});return c}});Module.prototype.base=Module.prototype.extend=_b;function _f(a,b){var c=a.prototype;var d=a.toString().slice(1,-1);for(var e in b){var f=b[e],g="";if(e.indexOf("@")==0){if(detect(e.slice(1)))_f(a,f)}else if(!c[e]){if(e==e.toUpperCase()){g="var "+e+"="+d+"."+e+";"}else if(typeof f=="function"&&f.call){g="var "+e+"=base2.lang.bind('"+e+"',"+d+");";c[e]=_q(a,e)}if(a.namespace.indexOf(g)==-1){a.namespace+=g}}}};function _p(a,b){return function(){return a[b].apply(a,arguments)}};function _q(b,c){return function(){var a=_2.call(arguments);a.unshift(this);return b[c].apply(b,a)}};var Enumerable=Module.extend({every:function(c,d,e){var f=true;try{forEach(c,function(a,b){f=d.call(e,a,b,c);if(!f)throw StopIteration;})}catch(error){if(error!=StopIteration)throw error;}return!!f},filter:function(d,e,f){var g=0;return this.reduce(d,function(a,b,c){if(e.call(f,b,c,d)){a[g++]=b}return a},[])},invoke:function(b,c){var d=_2.call(arguments,2);return this.map(b,(typeof c=="function")?function(a){return a==null?undefined:c.apply(a,d)}:function(a){return a==null?undefined:a[c].apply(a,d)})},map:function(c,d,e){var f=[],g=0;forEach(c,function(a,b){f[g++]=d.call(e,a,b,c)});return f},pluck:function(b,c){return this.map(b,function(a){return a==null?undefined:a[c]})},reduce:function(c,d,e,f){var g=arguments.length>2;forEach(c,function(a,b){if(g){e=d.call(f,e,a,b,c)}else{e=a;g=true}});return e},some:function(a,b,c){return!this.every(a,not(b),c)}});var _1="#";var Map=Base.extend({constructor:function(a){if(a)this.merge(a)},clear:function(){for(var a in this)if(a.indexOf(_1)==0){delete this[a]}},copy:function(){base2.__prototyping=true;var a=new this.constructor;delete base2.__prototyping;for(var b in this)if(this[b]!==a[b]){a[b]=this[b]}return a},forEach:function(a,b){for(var c in this)if(c.indexOf(_1)==0){a.call(b,this[c],c.slice(1),this)}},get:function(a){return this[_1+a]},getKeys:function(){return this.map(II)},getValues:function(){return this.map(I)},has:function(a){/*@cc_on @*/ /*@if(@_jscript_version<5.5)return $Legacy.has(this,_1+a);@else @*/return _1+a in this;/*@end @*/},merge:function(b){var c=flip(this.put);forEach(arguments,function(a){forEach(a,c,this)},this);return this},put:function(a,b){this[_1+a]=b;return b},remove:function(a){delete this[_1+a]},size:function(){var a=0;for(var b in this)if(b.indexOf(_1)==0)a++;return a},union:function(a){return this.merge.apply(this.copy(),arguments)}});Map.implement(Enumerable);Map.prototype.filter=function(d,e){return this.reduce(function(a,b,c){if(!d.call(e,b,c,this)){a.remove(c)}return a},this.copy(),this)};var _0="~";var Collection=Map.extend({constructor:function(a){this[_0]=new Array2;this.base(a)},add:function(a,b){if(this.has(a))throw"Duplicate key '"+a+"'.";this.put.apply(this,arguments)},clear:function(){this.base();this[_0].length=0},copy:function(){var a=this.base();a[_0]=this[_0].copy();return a},forEach:function(a,b){var c=this[_0];var d=c.length;for(var e=0;e<d;e++){a.call(b,this[_1+c[e]],c[e],this)}},getAt:function(a){var b=this[_0].item(a);return(b===undefined)?undefined:this[_1+b]},getKeys:function(){return this[_0].copy()},indexOf:function(a){return this[_0].indexOf(String(a))},insertAt:function(a,b,c){if(this[_0].item(a)==null)throw"Index out of bounds.";if(this.has(b))throw"Duplicate key '"+b+"'.";this[_0].insertAt(a,String(b));this[_1+b]=null;this.put.apply(this,_2.call(arguments,1))},item:function(a){return this[typeof a=="number"?"getAt":"get"](a)},put:function(a,b){var c=this.constructor;if(c.Item&&!instanceOf(b,c.Item)){b=c.create.apply(c,arguments)}if(!this.has(a)){this[_0].push(String(a))}this[_1+a]=b;return b},putAt:function(a,b){arguments[0]=this[_0].item(a);if(arguments[0]==null)throw"Index out of bounds.";this.put.apply(this,arguments)},remove:function(a){if(this.has(a)){this[_0].remove(String(a));delete this[_1+a]}},removeAt:function(a){var b=this[_0].item(a);if(b!==undefined){this[_0].removeAt(a);delete this[_1+b]}},reverse:function(){this[_0].reverse();return this},size:function(){return this[_0].length},slice:function(a,b){var c=this.copy();if(arguments.length>0){var d=this[_0],e=d;c[_0]=Array2(_2.apply(d,arguments));if(c[_0].length){e=e.slice(0,a);if(arguments.length>1){e=e.concat(d.slice(b))}}for(var f=0;f<e.length;f++){delete c[_1+e[f]]}}return c},sort:function(c){if(c){this[_0].sort(bind(function(a,b){return c(this[_1+a],this[_1+b],a,b)},this))}else this[_0].sort();return this},toString:function(){return"("+(this[_0]||"")+")"}},{Item:null,create:function(a,b){return this.Item?new this.Item(a,b):b},extend:function(a,b){var c=this.base(a);c.create=this.create;if(b)extend(c,b);if(!c.Item){c.Item=this.Item}else if(typeof c.Item!="function"){c.Item=(this.Item||Base).extend(c.Item)}if(c.init)c.init();return c}});var _r=/\\(\d+)/g,_s=/\\./g,_t=/\(\?[:=!]|\[[^\]]+\]/g,_u=/\(/g,_v=/\$(\d+)/,_w=/^\$\d+$/;var RegGrp=Collection.extend({constructor:function(a,b){this.base(a);this.ignoreCase=!!b},ignoreCase:false,exec:function(g,h){g+="";var j=this,i=this[_0];if(!i.length)return g;if(h==RegGrp.IGNORE)h=0;return g.replace(new RegExp(this,this.ignoreCase?"gi":"g"),function(a){var b,c=1,d=0;while((b=j[_1+i[d++]])){var e=c+b.length+1;if(arguments[c]){var f=h==null?b.replacement:h;switch(typeof f){case"function":return f.apply(j,_2.call(arguments,c,e));case"number":return arguments[c+f];default:return f}}c=e}return a})},insertAt:function(a,b,c){if(instanceOf(b,RegExp)){arguments[1]=b.source}return this.base.apply(this,arguments)},test:function(a){return this.exec(a)!=a},toString:function(){var e=1;return"("+this.map(function(c){var d=(c+"").replace(_r,function(a,b){return"\\"+(e+Number(b))});e+=c.length+1;return d}).join(")|(")+")"}},{IGNORE:"$0",init:function(){forEach("add,get,has,put,remove".split(","),function(b){_a(this,b,function(a){if(instanceOf(a,RegExp)){arguments[0]=a.source}return this.base.apply(this,arguments)})},this.prototype)},Item:{constructor:function(a,b){if(b==null)b=RegGrp.IGNORE;else if(b.replacement!=null)b=b.replacement;else if(typeof b!="function")b=String(b);if(typeof b=="string"&&_v.test(b)){if(_w.test(b)){b=parseInt(b.slice(1),10)}else{var c='"';b=b.replace(/\\/g,"\\\\").replace(/"/g,"\\x22").replace(/\n/g,"\\n").replace(/\r/g,"\\r").replace(/\$(\d+)/g,c+"+(arguments[$1]||"+c+c+")+"+c).replace(/(['"])\1\+(.*)\+\1\1$/,"$1");b=new Function("return "+c+b+c)}}this.length=RegGrp.count(a);this.replacement=b;this.toString=K(a+"")},length:0,replacement:""},count:function(a){a=(a+"").replace(_s,"").replace(_t,"");return match(a,_u).length}});var lang={name:"lang",version:base2.version,exports:"assert,assertArity,assertType,bind,copy,extend,forEach,format,instanceOf,match,pcopy,rescape,trim,typeOf",namespace:""};function assert(a,b,c){if(!a){throw new(c||Error)(b||"Assertion failed.");}};function assertArity(a,b,c){if(b==null)b=a.callee.length;if(a.length<b){throw new SyntaxError(c||"Not enough arguments.");}};function assertType(a,b,c){if(b&&(typeof b=="function"?!instanceOf(a,b):typeOf(a)!=b)){throw new TypeError(c||"Invalid type.");}};function copy(a){var b={};for(var c in a){b[c]=a[c]}return b};function pcopy(a){_g.prototype=a;return new _g};function _g(){};function extend(a,b){if(a&&b){var c=base2.__prototyping;if(arguments.length>2){var d=b;b={};b[d]=arguments[2];c=true}var e=global[(typeof b=="function"?"Function":"Object")].prototype;if(c){var f=_d.length,d;while((d=_d[--f])){var g=b[d];if(g!=e[d]){if(_c.test(g)){_a(a,d,g)}else{a[d]=g}}}}for(d in b){if(e[d]===undefined){g=b[d];if(d.indexOf("@")==0){if(detect(d.slice(1)))extend(a,g)}else if(g!=_b){var h=a[d];if(h&&typeof g=="function"){if(g!=h){if(_c.test(g)){_a(a,d,g)}else{g.ancestor=h;a[d]=g}}}else{a[d]=g}}}}}return a};function _9(a,b){while(b){if(!b.ancestor)return false;b=b.ancestor;if(b==a)return true}return false};function _a(c,d,e){var f=c[d];var g=base2.__prototyping;if(g&&f!=g[d])g=null;function h(){var a=this.base;this.base=g?g[d]:f;var b=e.apply(this,arguments);this.base=a;return b};h.method=e;h.ancestor=f;c[d]=h;c=null};if(typeof StopIteration=="undefined"){StopIteration=new Error("StopIteration")}function forEach(a,b,c,d){if(a==null)return;if(!d){if(typeof a=="function"&&a.call){d=Function}else if(typeof a.forEach=="function"&&a.forEach!=arguments.callee){a.forEach(b,c);return}else if(typeof a.length=="number"){_6(a,b,c);return}}_5(d||Object,a,b,c)};forEach.csv=function(a,b,c){forEach(csv(a),b,c)};forEach.detect=function(c,d,e){forEach(c,function(a,b){if(b.indexOf("@")==0){if(detect(b.slice(1)))forEach(a,arguments.callee)}else d.call(e,a,b,c)})};function _6(a,b,c){if(a==null)a=global;var d=a.length||0,e;if(typeof a=="string"){for(e=0;e<d;e++){b.call(c,a.charAt(e),e,a)}}else{for(e=0;e<d;e++){/*@cc_on @*/ /*@if(@_jscript_version<5.2)if($Legacy.has(a,e))@else @*/if(e in a)/*@end @*/b.call(c,a[e],e,a)}}};function _5(g,h,j,i){var k=function(){this.i=1};k.prototype={i:1};var l=0;for(var o in new k)l++;_5=(l>1)?function(a,b,c,d){var e={};for(var f in b){if(!e[f]&&a.prototype[f]===undefined){e[f]=true;c.call(d,b[f],f,b)}}}:function(a,b,c,d){for(var e in b){if(a.prototype[e]===undefined){c.call(d,b[e],e,b)}}};_5(g,h,j,i)};function instanceOf(a,b){if(typeof b!="function"){throw new TypeError("Invalid 'instanceOf' operand.");}if(a==null)return false;/*@cc_on if(typeof a.constructor!="function"){return b==Object}@*/if(a.constructor==b)return true;if(b.ancestorOf)return b.ancestorOf(a.constructor);/*@if(@_jscript_version<5.1)@else @*/if(a instanceof b)return true;/*@end @*/if(Base.ancestorOf==b.ancestorOf)return false;if(Base.ancestorOf==a.constructor.ancestorOf)return b==Object;switch(b){case Array:return _7.call(a)=="[object Array]";case Date:return _7.call(a)=="[object Date]";case RegExp:return _7.call(a)=="[object RegExp]";case Function:return typeOf(a)=="function";case String:case Number:case Boolean:return typeOf(a)==typeof b.prototype.valueOf();case Object:return true}return false};var _7=Object.prototype.toString;function typeOf(a){var b=typeof a;switch(b){case"object":return a==null?"null":typeof a.constructor!="function"?_l.test(a)?"function":b:_7.call(a)=="[object Date]"?b:typeof a.constructor.prototype.valueOf();case"function":return typeof a.call=="function"?b:"object";default:return b}};var JavaScript={name:"JavaScript",version:base2.version,exports:"Array2,Date2,Function2,String2",namespace:"",bind:function(c){var d=global;global=c;forEach.csv(this.exports,function(a){var b=a.slice(0,-1);extend(c[b],this[a]);this[a](c[b].prototype)},this);global=d;return c}};function _8(b,c,d,e){var f=Module.extend();var g=f.toString().slice(1,-1);forEach.csv(d,function(a){f[a]=unbind(b.prototype[a]);f.namespace+=format("var %1=%2.%1;",a,g)});forEach(_2.call(arguments,3),f.implement,f);var h=function(){return f(this.constructor==f?c.apply(null,arguments):arguments[0])};h.prototype=f.prototype;for(var j in f){if(j!="prototype"&&j!="toString"&&b[j]){f[j]=b[j];delete f.prototype[j]}h[j]=f[j]}h.ancestor=Object;delete h.extend;h.namespace=h.namespace.replace(/(var (\w+)=)[^,;]+,([^\)]+)\)/g,"$1$3.$2");return h};if((new Date).getYear()>1900){Date.prototype.getYear=function(){return this.getFullYear()-1900};Date.prototype.setYear=function(a){return this.setFullYear(a+1900)}}var _h=new Date(Date.UTC(2006,1,20));_h.setUTCDate(15);if(_h.getUTCHours()!=0){forEach.csv("FullYear,Month,Date,Hours,Minutes,Seconds,Milliseconds",function(b){extend(Date.prototype,"setUTC"+b,function(){var a=this.base.apply(this,arguments);if(a>=57722401000){a-=3600000;this.setTime(a)}return a})})}Function.prototype.prototype={};if("".replace(/^/,K("$$"))=="$"){extend(String.prototype,"replace",function(a,b){if(typeof b=="function"){var c=b;b=function(){return String(c.apply(null,arguments)).split("$").join("$$")}}return this.base(a,b)})}var Array2=_8(Array,Array,"concat,join,pop,push,reverse,shift,slice,sort,splice,unshift",Enumerable,{batch:function(d,e,f,g,h){var j=0,i=d.length;setTimeout(function(){var a=Date2.now(),b=a,c=0;while(j<i&&(a-b<f)){e.call(h,d[j],j++,d);if(c++<5||c%50==0)a=Date2.now()}if(j<i){setTimeout(arguments.callee,10)}else{if(g)g.call(h)}},1)},combine:function(d,e){if(!e)e=d;return Array2.reduce(d,function(a,b,c){a[b]=e[c];return a},{})},contains:function(a,b){return Array2.indexOf(a,b)!=-1},copy:function(a){var b=_2.call(a);if(!b.swap)Array2(b);return b},flatten:function(c){var d=0;return Array2.reduce(c,function(a,b){if(Array2.like(b)){Array2.reduce(b,arguments.callee,a)}else{a[d++]=b}return a},[])},forEach:_6,indexOf:function(a,b,c){var d=a.length;if(c==null){c=0}else if(c<0){c=Math.max(0,d+c)}for(var e=c;e<d;e++){if(a[e]===b)return e}return-1},insertAt:function(a,b,c){Array2.splice(a,b,0,c)},item:function(a,b){if(b<0)b+=a.length;return a[b]},lastIndexOf:function(a,b,c){var d=a.length;if(c==null){c=d-1}else if(c<0){c=Math.max(0,d+c)}for(var e=c;e>=0;e--){if(a[e]===b)return e}return-1},map:function(c,d,e){var f=[];_6(c,function(a,b){f[b]=d.call(e,a,b,c)});return f},remove:function(a,b){var c=Array2.indexOf(a,b);if(c!=-1)Array2.removeAt(a,c)},removeAt:function(a,b){Array2.splice(a,b,1)},swap:function(a,b,c){if(b<0)b+=a.length;if(c<0)c+=a.length;var d=a[b];a[b]=a[c];a[c]=d;return a}});Array2.forEach=_6;Array2.reduce=Enumerable.reduce;Array2.like=function(a){return typeOf(a)=="object"&&typeof a.length=="number"};var _x=/^((-\d+|\d{4,})(-(\d{2})(-(\d{2}))?)?)?T((\d{2})(:(\d{2})(:(\d{2})(\.(\d{1,3})(\d)?\d*)?)?)?)?(([+-])(\d{2})(:(\d{2}))?|Z)?$/;var _4={FullYear:2,Month:4,Date:6,Hours:8,Minutes:10,Seconds:12,Milliseconds:14};var _3={Hectomicroseconds:15,UTC:16,Sign:17,Hours:18,Minutes:20};var Date2=_8(Date,function(a,b,c,d,e,f,g){switch(arguments.length){case 0:return new Date;case 1:return typeof a=="number"?new Date(a):new Date(Date2.parse(a));default:return new Date(a,b,arguments.length==2?1:c,d||0,e||0,f||0,g||0)}},"",{toISOString:function(c){var d="####-##-##T##:##:##.###";for(var e in _4){d=d.replace(/#+/,function(a){var b=c["getUTC"+e]();if(e=="Month")b++;return("000"+b).slice(-a.length)})}return d+"Z"}});delete Date2.forEach;Date2.now=function(){return(new Date).valueOf()};Date2.parse=function(a,b){if(arguments.length>1){assertType(b,"number","Default date should be of type 'number'.")}var c=match(a,_x);if(c.length){if(c[_4.Month])c[_4.Month]--;if(c[_3.Hectomicroseconds]>=5)c[_4.Milliseconds]++;var d=new Date(b||0);var e=c[_3.UTC]||c[_3.Hours]?"UTC":"";for(var f in _4){var g=c[_4[f]];if(g){d["set"+e+f](g);if(d["get"+e+f]()!=c[_4[f]]){return NaN}}}if(c[_3.Hours]){var h=Number(c[_3.Sign]+c[_3.Hours]);var j=Number(c[_3.Sign]+(c[_3.Minutes]||0));d.setUTCMinutes(d.getUTCMinutes()+(h*60)+j)}return d.valueOf()}else{return Date.parse(a)}};var String2=_8(String,function(a){return new String(arguments.length==0?"":a)},"charAt,charCodeAt,concat,indexOf,lastIndexOf,match,replace,search,slice,split,substr,substring,toLowerCase,toUpperCase",{csv:csv,format:format,rescape:rescape,trim:trim});delete String2.forEach;function trim(a){return String(a).replace(_i,"").replace(_j,"")};function csv(a){return a?(a+"").split(/\s*,\s*/):[]};function format(c){var d=arguments;var e=new RegExp("%([1-"+(arguments.length-1)+"])","g");return(c+"").replace(e,function(a,b){return d[b]})};function match(a,b){return(a+"").match(b)||[]};function rescape(a){return(a+"").replace(_k,"\\$1")};var Function2=_8(Function,Function,"",{I:I,II:II,K:K,bind:bind,compose:compose,delegate:delegate,flip:flip,not:not,partial:partial,unbind:unbind});function I(a){return a};function II(a,b){return b};function K(a){return function(){return a}};function bind(a,b){var c=typeof a!="function";if(arguments.length>2){var d=_2.call(arguments,2);return function(){return(c?b[a]:a).apply(b,d.concat.apply(d,arguments))}}else{return function(){return(c?b[a]:a).apply(b,arguments)}}};function compose(){var c=_2.call(arguments);return function(){var a=c.length,b=c[--a].apply(this,arguments);while(a--)b=c[a].call(this,b);return b}};function delegate(b,c){return function(){var a=_2.call(arguments);a.unshift(this);return b.apply(c,a)}};function flip(a){return function(){return a.apply(this,Array2.swap(arguments,0,1))}};function not(a){return function(){return!a.apply(this,arguments)}};function partial(d){var e=_2.call(arguments,1);return function(){var a=e.concat(),b=0,c=0;while(b<e.length&&c<arguments.length){if(a[b]===undefined)a[b]=arguments[c++];b++}while(c<arguments.length){a[b++]=arguments[c++]}if(Array2.contains(a,undefined)){a.unshift(d);return partial.apply(null,a)}return d.apply(this,a)}};function unbind(b){return function(a){return b.apply(a,_2.call(arguments,1))}};function detect(){var e=NaN/*@cc_on||@_jscript_version@*/;var f=global.java?true:false;if(global.navigator){var g=/MSIE[\d.]+/g;var h=document.createElement("span"),j=h.style;h.expando=1;var i=navigator.userAgent.replace(/([a-z])[\s\/](\d)/gi,"$1$2");if(!e)i=i.replace(g,"");if(g.test(i))i=i.match(g)[0]+" "+i.replace(g,"");if(/Gecko/.test(i))i=i.replace(/rv:/,"Gecko");if(!/Compat$/.test(document.compatMode))i+=";QuirksMode";base2.userAgent=navigator.platform+" "+i.replace(/like \w+/gi,"");f&=navigator.javaEnabled()}var k={};detect=function(a){if(k[a]==null){var b=false,c=a;var d=c.indexOf("!")==0;if(d)c=c.slice(1);if(c.indexOf("(")==0){try{b=new Function("element,style,jscript,java,global","return !!"+c)(h,j,e,f,global)}catch(ex){}}else{b=new RegExp("("+c+")","i").test(base2.userAgent)}k[a]=!!(d^b)}return k[a]};return detect(arguments[0])};base2=global.base2=new Package(this,base2);var exports=this.exports;lang=new Package(this,lang);exports+=this.exports;JavaScript=new Package(this,JavaScript);eval(exports+this.exports);lang.extend=extend};

eval(base2.namespace);
eval(Enumerable.namespace);
eval(lang.namespace);

var DEFAULT = "@0";
var IGNORE  = RegGrp.IGNORE;

var Colorizer = RegGrp.extend({
  constructor: function(patterns, replacements, properties) {
    this.extend(properties);
    this.patterns = patterns || {};
    var values = {}, i;
    forEach (patterns, function(pattern, className) {
      values[className] = replacements[className] || DEFAULT;
    });
    forEach (replacements, function(replacement, className) {
      values[className] = replacements[className];
    });
    this.base(values);
  },
  
  patterns: null,
  tabStop: 4,
  urls: true,

  copy: function() {
    var colorizer = this.base();
    colorizer.patterns = copy(this.patterns);
    return colorizer;
  },
  
  exec: function(text, secondary) {
    text = this.base(this.escape(text));
    if (!secondary) { // Not a secondary parse of the text (e.g. CSS within an HTML sample)
      text = this._parseWhiteSpace(text);
      if (this.urls) text = Colorizer.urls.exec(text);
    }
    return this.unescape(text);
  },

  escape: function(text) {
    return String(text).replace(/</g, "\x01").replace(/&/g, "\x02");
  },

  put: function(pattern, replacement) {
    // This is a bit complicated and is therefore probably wrong.
    if (!instanceOf(pattern, RegGrp.Item)) {
      if (typeof replacement == "string") {
        replacement = replacement.replace(/@(\d)/, function(match, index) {
          return format(Colorizer.FORMAT, pattern, index);
        });
      }
      pattern = this.patterns[pattern] || Colorizer.patterns[pattern] || pattern;
      if (instanceOf(pattern, RegExp)) pattern = pattern.source;
      pattern = this.escape(pattern);
    }
    return this.base(pattern, replacement);
  },

  unescape: function(text) {
    return text.replace(/\x01/g, "&lt;").replace(/\x02/g, "&amp;");
  },

  _parseWhiteSpace: function(text) {
    // Convert tabs to spaces and then convert spaces to "&nbsp;".
    var tabStop = this.tabStop;
    if (tabStop > 0) {
      var tab = Array(tabStop + 1).join(" ");
      return text.replace(Colorizer.TABS, function(match) {
        match = match.replace(Colorizer.TAB, tab);
        if (tabStop > 1) {
          var padding = (match.length - 1) % tabStop;
          if (padding) match = match.slice(0, -padding);
        }
        return match.replace(/ /g, "&nbsp;");
      });
    }
    return text;
  },

  "@MSIE": {
    _parseWhiteSpace: function(text) {
      return this.base(text).replace(/\r?\n/g, "<br>");
    }
  }
}, {
  version: "0.8",
  
  FORMAT: '<span class="%1">$%2</span>',
  DEFAULT: DEFAULT,
  IGNORE:  IGNORE,  
  TAB:     /\t/g,
  TABS:    /\n([\t \xa0]+)/g,
  
  init: function() {
    // Patterns that are defined as Arrays represent
    // groups of other patterns. Build those groups.
    forEach (this.patterns, function(pattern, name, patterns) {
      if (instanceOf(pattern, Array)) {
        patterns[name] = reduce(pattern, function(group, name) {
          group.add(patterns[name]);
          return group;
        }, new RegGrp);
      }
    });
    this.urls = this.patterns.urls.copy();
    this.urls.putAt(0, '<a href="mailto:$0">$0</a>');
    this.urls.putAt(1, '<a href="$0">$0</a>');
  },

  addScheme: function(name, patterns, replacements, properties) {
    this[name] = new this(patterns, replacements, properties);
  },
  
  // Pre-defined regular expressions.
  patterns: {
    block_comment: /\/\*[^*]*\*+([^\/][^*]*\*+)*\//,
    email:         /([\w.+-]+@[\w.-]+\.\w+)/,
    line_comment:  /\/\/[^\r\n]*/,
    number:        /\b\-?(0|[1-9]\d*)(\.\d+)?([eE][-+]?\d+)?\b/,
    string1:       /'(\\.|[^'\\])*'/,
    string2:       /"(\\.|[^"\\])*"/,
    url:           /(http:\/\/+[\w\/\-%&#=.,?+$]+)/,
    // groups
    comment:       ["block_comment", "line_comment"],
    string:        ["string1", "string2"],
    urls:          ["email", "url"]
  },
  
  urls: null
});

base2.addPackage("code");
base2.code.addName("Colorizer", Colorizer);

with (base2.code.Colorizer) addScheme("javascript", {
  conditional: /\/\*@if\s*\([^\)]*\)|\/\*@[\s\w]*|@\*\/|\/\/@\w+|@else[\s\w]*/, // conditional comments
  global:      /\b(clearInterval|clearTimeout|constructor|document|escape|hasOwnProperty|Infinity|isNaN|NaN|parseFloat|parseInt|prototype|setInterval|setTimeout|toString|unescape|valueOf|window)\b/,
  keyword:     /\b(&&|\|\||arguments|break|case|continue|default|delete|do|else|false|for|function|if|in|instanceof|new|null|return|switch|this|true|typeof|var|void|while|with|undefined)\b/,
  regexp:      /([\[(\^=,{}:;&|!*?]\s*)(\/(\\\/|[^\/*])(\\.|[^\/\n\\])*\/[mgi]*)/, /* -- */
  special:     /\b(assert\w*|catch|confirm|debug|debugger|eval|finally|throw|try)\b/
}, {
  comment:     DEFAULT,
  string:      DEFAULT,
  regexp:      "$1@2",
  number:      DEFAULT
}, {
  tabStop: 2
});

with (base2.code.Colorizer.javascript) {
  add("\\bbehavior\\b", '<i>$0</i>');
  add("\\b(" + ([base2.exports,base2.JavaScript.exports,lang.exports].join(",") + ",attach,detach,modify,get,set,ancestorOf,base,base2,merge,union,implement,I,II,K").match(/[^\s,]+/g).join("|") + ")\\b", '<span class="base2">$0</span>');
  insertAt(0, /("@[^"]+"):/, '<span class="detect">$1</span>:');
  insertAt(1, /\.behavior\b/, IGNORE);
}

with (base2.code.Colorizer) addScheme("xml", {
  attribute: /(\w+)=("[^"]*"|'[^']*')/,
  cdata:     /<!\[CDATA\[([^\]]|\][^\]]|\]\][^>])*\]\]>/,
  comment:   /<!\s*(--([^-]|[\r\n]|-[^-])*--\s*)>/,
  entity:    /&#?\w+;/,
  "processing-instruction": /<\?[\w-]+[^>]+>/,
  tag:       /(<\/?)([\w:-]+)/,
  text:      /[>;][^<>&]*/
}, {
  cdata:     IGNORE,
  tag:       "$1@2",
  attribute: '@1=<span class="attribute value">$2</span>',
  text:      IGNORE
}, {
  tabStop:   1
});

with (base2) code.Colorizer.addScheme("html", {
  conditional: /<!(--)?\[[^\]]*\]>|<!\[endif\](--)?>/, // conditional comments
  doctype:     /<!DOCTYPE[^>]+>/,
  inline:      /<(script|style)([^>]*)>((\\.|[^\\])*)<\/\1>/
}, {
  inline: function(match, tagName, attributes, cdata) {
    return format(this.INLINE, tagName, this.exec(attributes, true), cdata);
  }
}, {
  INLINE: '&lt;<span class="tag">%1</span>%2&gt;%3&lt;/<span class="tag">%1</span>&gt;',
  tabStop: 1
});

with (base2.code.Colorizer) html.merge(xml);

onload = function() {
  var pres = document.getElementsByTagName("pre"), pre;
  for (var i = 0; pre = pres[i]; i++) {
    if (/javascript/.test(pre.className)) {
      pre.innerHTML = Colorizer.javascript.exec(pre.textContent || pre.innerText);
      pre.className += " highlight";
    } else if (/html/.test(pre.className)) {
      pre.innerHTML = Colorizer.html.exec(pre.textContent || pre.innerText);
      pre.className += " highlight";
    }
  }
};